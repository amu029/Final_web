<template>
  <div class="grandmaster-card">
    <h2>{{ grandmaster.name }}</h2>
    <img :src="grandmaster.image_url" alt="Grandmaster Photo" class="grandmaster-image" />
    <div class="grandmaster-details">
      <p><strong>Country:</strong> {{ grandmaster.country_of_origin }}</p>
      <p><strong>Titles:</strong> {{ grandmaster.titles_held.join(', ') }}</p>
      <p><strong>Peak Elo Rating:</strong> {{ grandmaster.peak_elo_rating }}</p>
      <p><strong>Games Played:</strong> {{ grandmaster.number_of_games_played }}</p>
      <p><strong>Total Wins:</strong> {{ grandmaster.total_wins }}</p>
      <p><strong>Active Years:</strong> {{ grandmaster.active_years.start_year }} - {{ grandmaster.active_years.end_year || 'Present' }}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "GrandmasterCard",
  props: {
    grandmaster: Object
  }
};
</script>

<style scoped>
.grandmaster-card {
  display: block;
  width: 95%; 
  height: fit-content;
  padding: 25px;
  background-color: var(--secondary-color);
  border-radius: 12px;
  box-shadow: 0px 5px 15px var(--shadow-color);
  text-align: left;;
  border: 2px solid var(--accent-color);
  border-right: 4px solid var(--primary-color); 
  
}

.grandmaster-image {
  width: 200px;
  height: 200px;
  border-radius: 5%;
  margin-bottom: 100px;
  margin-top: -30px;
  object-fit: cover;
  border: 3px solid var(--accent-color);

  float: left;
  margin-left: 100px;
}

.grandmaster-details {
  text-align: right; 
  margin-right: 100px;
}

.grandmaster-card h2 {
  color: var(--primary-color);
  font-size: 1.6rem;
  text-align: center;
  margin-top: 40px;
  
}

.grandmaster-card p {
  color: var(--primary-color);
  font-size: 1.1rem;
  margin: 8px 0;
  margin-bottom: 10px;
}

.grandmaster-card strong {
  color: var(--primary-color);
}

.clearfix::after {
  content: "";
  display: table;
  clear: both;
}
</style>
