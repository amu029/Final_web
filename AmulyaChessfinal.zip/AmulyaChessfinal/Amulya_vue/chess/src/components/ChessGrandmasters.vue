<template>
  <div class="chess-grandmasters">
    <h1 class="title">Chess Grandmasters</h1>
    <div v-if="grandmasters.length === 0" class="loading">
      <div class="loading-spinner"></div>
      <p>Loading Grandmasters...</p>
    </div>
    <div v-else class="grandmaster-container">
      <GrandmasterList :grandmasters="grandmasters" />
    </div>
  </div>
</template>

<script>
import GrandmasterList from './GrandmasterList.vue';

export default {
  name: 'ChessGrandmasters',
  components: {
    GrandmasterList,
  },

/*data from api*/
  data() {
    return {
      grandmasters: [],
      error: ''
    };
  },
  created() {
  fetch("http://localhost:5000/api")
    .then((response) => response.json())
    .then((data) => {
      console.log('Fetched data:', data);
      
      
      if (Array.isArray(data) && data[0] && data[0].grandmasters && Array.isArray(data[0].grandmasters)) {
        
        this.grandmasters = data[0].grandmasters.map((grandmaster) => {
          return {
            ...grandmaster, 
            id: grandmaster.name, 
          };
        });
      } else {
        console.error('No grandmasters found in the data or invalid format');
        this.error = 'Error loading grandmasters. Data format is invalid or missing.';
      }
    })
    .catch((error) => {
      console.error("Error fetching data:", error);
      this.error = 'Error loading grandmasters. Please try again.';
    });
}

};
</script>

<style>

:root {
  --primary-color: #003366; 
  --secondary-color: #F1E6B9; 
  --accent-color: #8B0000; 
  --highlight-color: #D4AF37; 
  --background-gradient: linear-gradient(to bottom right, #003366, #F1E6B9);
  --text-color: #1C1C1C; 
}

.chess-grandmasters {
  text-align: center;
  padding: 40px;
  background: var(--background-gradient);
  color: var(--text-color);
  min-height: 100vh;
}

.title {
  font-size: 3.2rem; 
  font-family: 'Roboto', sans-serif;
  font-weight: bold; 
  margin-bottom: 30px;
   
  color:#000000;
  background: linear-gradient(to left, var(--primary-color), var(--highlight-color)); 
 
  padding: 5px 10px; 
  border-radius: 10px; 
}

.loading {
  display: block;
  text-align: center;
}

.grandmaster-container {
  padding: 20px;
}

.grandmaster-card {
  display: block;
  width: 100%;
  padding: 25px;
  background-color: var(--secondary-color);
  border-radius: 12px;
  box-shadow: 0px 5px 15px var(--shadow-color);
  text-align: left;
  margin: 15px 0;
  border: 2px solid var(--accent-color);
  transition: box-shadow 0.3s ease;
}

.grandmaster-card:hover {
  box-shadow: 0px 8px 20px var(--shadow-color);
}

.grandmaster-image {
  width: 160px;
  height: 160px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid var(--accent-color); 
  margin-right: 20px;
  float: left;
}

.grandmaster-card h2 {
  color: var(--primary-color); 
  font-size: 1.8rem;
  text-align: left;
  margin-top: 15px;
}

.grandmaster-card p {
  color: var(--primary-color); 
  font-size: 1.1rem;
  margin: 8px 0;
}

.grandmaster-card strong {
  color: var(--primary-color); 
}

.clearfix::after {
  content: "";
  display: table;
  clear: both;
}
</style>
