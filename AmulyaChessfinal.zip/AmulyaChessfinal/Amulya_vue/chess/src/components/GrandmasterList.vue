<template>
  <ul class="grandmaster-list">
    <li v-for="(grandmaster, index) in grandmasters" :key="index">
      <GrandmasterCard :grandmaster="grandmaster" />
    </li>
  </ul>
</template>

<script>
import GrandmasterCard from './GrandmasterCard.vue';

export default {
  name: 'GrandmasterList',
  components: {
    GrandmasterCard,
  },
  props: {
    grandmasters: {
      type: Array,
      required: true,
    },
  },
};
</script>

<style scoped>
.grandmaster-list {
  list-style-type: none;
  padding: 0;
  margin: 0;
  width: 100%; 
}

.grandmaster-list li {
  margin: 0 0 20px;
}
</style>
