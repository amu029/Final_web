const { MongoClient } = require('mongodb');

const uri = 'mongodb+srv://amu:amu@cluster0.jz2mj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

const client = new MongoClient(uri);

async function run() {
  try {
    await client.connect();
    console.log('Connected to MongoDB successfully!');
  } finally {
    await client.close();
  }
}

run().catch(console.error);
