const http = require('http');
const fs = require('fs');
const path = require('path');
const { MongoClient } = require('mongodb');
const url = require('url');

// MongoDB connection configuration
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://amu:amu@cluster0.jz2mj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
const DB_NAME = process.env.MONGODB_DB_NAME || 'chess';

// MongoDB client object
let client;
async function connectToMongoDB() {
  if (!client) {
    try {
      console.log('Connecting to MongoDB...');
      client = await MongoClient.connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
      console.log('MongoDB connected');
    } catch (error) {
      console.error('MongoDB connection failed:', error);
      throw error;
    }
  }
  return client;
}

// Create HTTP server
const server = http.createServer(async (req, res) => {
  console.log(`${req.method} ${req.url}`);

  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Parse the request URL
  const parsedUrl = url.parse(req.url, true);

  // API route for MongoDB data
  if (parsedUrl.pathname === '/api' && req.method === 'GET') {
    try {
      // Connect to MongoDB
      const client = await connectToMongoDB();
      const db = client.db(DB_NAME);
      const collection = db.collection('grandmasters');

      // Fetch data from MongoDB
      const data = await collection.find({}).toArray();
      console.log('Data fetched from MongoDB:', data);

     
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data)); /*sending JSON Response*/
      console.log('Sent data to client');
    } catch (error) {
      console.error('Error fetching data from MongoDB:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Error fetching data', error: error.message }));
    }
  } 
  // Serve static files for root and other routes
  else {
    let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);

    // Determine content type
    const extname = path.extname(filePath);
    let contentType = 'text/html';
    switch (extname) {
      case '.css':
        contentType = 'text/css';
        break;
      case '.png':
        contentType = 'image/png';
        break;
      case '.jpg':
      case '.jpeg':
        contentType = 'image/jpeg';
        break;
    }

    // Read and serve the file
    fs.readFile(filePath, (err, content) => {
      if (err) {
        if (err.code === 'ENOENT') {
          fs.readFile(path.join(__dirname, 'public', 'index.html'), (err, content) => {
            if (err) {
              res.writeHead(500);
              res.end('Error loading index.html');
            } else {
              res.writeHead(200, { 'Content-Type': 'text/html' });
              res.end(content);
            }
          });
        } else {
          res.writeHead(500);
          res.end(`Server Error: ${err.code}`);
        }
      } else {
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
      }
    });
  }
});

// Define the port
const PORT = process.env.PORT || 5000;

// Start the server
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
